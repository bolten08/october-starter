<?php return array (
  'october\\demo\\Plugin' => 'plugins/october/demo/Plugin.php',
  'backend\\Controllers\\auth' => 'modules/backend/controllers/auth.php',
  'backend\\Controllers\\index' => 'modules/backend/controllers/index.php',
  'backend\\Controllers\\users' => 'modules/backend/controllers/users.php',
);