<?php namespace October\Tester\Classes;

class Users
{
    public function getUsers()
    {
        return [
            'Art Vandelay' => 'Arquitecht and Importer/Exporter',
            'Carl' => 'where is he?',
        ];
    }
}
