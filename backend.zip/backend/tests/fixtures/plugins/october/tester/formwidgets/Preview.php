<?php namespace October\Tester\FormWidgets;

use Backend\Classes\FormWidgetBase;

class Preview extends FormWidgetBase
{
}
